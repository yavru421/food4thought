import { G, f } from "./mermaid-parser.core.kw5vybLY.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
