import { P, a } from "./mermaid-parser.core.kw5vybLY.js";
export {
  P as PacketModule,
  a as createPacketServices
};
