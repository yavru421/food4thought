import { I, c } from "./mermaid-parser.core.kw5vybLY.js";
export {
  I as InfoModule,
  c as createInfoServices
};
