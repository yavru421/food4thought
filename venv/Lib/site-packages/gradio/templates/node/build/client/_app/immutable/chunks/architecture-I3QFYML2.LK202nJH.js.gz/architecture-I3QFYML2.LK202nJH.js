import { A, e } from "./mermaid-parser.core.kw5vybLY.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
